﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace bupg_final.Models
{
    public class ExitData
    {
        public string Region { get; set; }
        public string CPName { get; set; }
        public string BillableStatus { get; set; }
        public string Kin { get; set; }
        public string BankId { get; set; }
        public string Name { get; set; }
        public string BillRate { get; set; }
        public string Role { get; set; }
        public string Skill { get; set; }
        public string EngagementType { get; set; }
        public string DeploymentType { get; set; }
        public string DateOfJoining { get; set; }
        public string Designation { get; set; }
        public string Location { get; set; }
        public string Entity { get; set; }
        public string ProjectName { get; set; }
        public string WOEndDate { get; set; }
        public DateTime SCBLwd { get; set; }
        public string DeallocationRaisedOn { get; set; }
        public string DeallocationDate { get; set; }
        public string ModeOfExit { get; set; }
        public string FinalStatus { get; set; }
        public string SCBExitStatus { get; set; }
        public string SkillSet { get; set; }
        public string Deployable { get; set; }
        public string ReplacementIdentified { get; set; }
        public string DeallocationStatus { get; set; }
        public string AccountLWD { get; set; }
        public string Comments { get; set; }
        public string ModifiedBy { get; set; }
        public string ModifiedOn { get; set; }
        [Key]
        public int PKey { get; set; }

        //public ExitData()
        //{
        //    this.SCBLwd = DateTime.Now.AddDays(30);
        //}
    }
}
